***************************************************
Old Numeric compatibility (:mod:`numpy.oldnumeric`)
***************************************************

.. currentmodule:: numpy

.. automodule:: numpy.oldnumeric
