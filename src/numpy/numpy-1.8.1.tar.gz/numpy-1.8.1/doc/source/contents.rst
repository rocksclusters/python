#####################
Numpy manual contents
#####################

.. toctree::

   user/index
   reference/index
   dev/index
   release
   about
   bugs
   license
   glossary
