#!/usr/bin/env python
from __future__ import division, absolute_import, print_function

from numpyx import test
test()
